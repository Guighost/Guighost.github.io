  document.addEventListener("DOMContentLoaded", function () {
    
    GamePix.loaded().then(function () {
     
      farming.start();
      })        
   
  });