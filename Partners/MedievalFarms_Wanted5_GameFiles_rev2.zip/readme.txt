This game was originall based on source code from the following:

HTML5 Farming Demo created by Pablo Farias Navarro
@ZenvaTweets
www.pablofarias.com
==================================================
License of the code: GLP 3.0    http://opensource.org/licenses/gpl-3.0.html

The images were created by Daneeklu and released under CC-BY-SA  (http://opengameart.org/content/lpc-farming-tilesets-magic-animations-and-ui-elements)