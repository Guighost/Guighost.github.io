  document.addEventListener("DOMContentLoaded", function () {
            farming.start();
        });